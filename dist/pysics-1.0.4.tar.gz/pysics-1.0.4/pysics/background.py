import math,sys,os

class background():
	def __init__(self,screen):
		self.screen = screen

	def fill(self,color):
		self.screen.fill(color)

